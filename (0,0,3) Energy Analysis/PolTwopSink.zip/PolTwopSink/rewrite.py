import numpy as np
import glob as glob

def data_reader_2pt(npt_data,index):
        results=[]
        t_bin=[]

        for i in range(len(npt_data)):
                infile = open(npt_data[i],'r')
                data = infile.readlines()

                for line in data:
                        sline = line.split(' ')[index]
                        results.append(sline)
                        infile.close()

        data = np.array([s.replace('\n','') for s in results])
        data=np.array([s.strip('+') for s in data])
        data=np.array(data.astype(float))

        return(data)

######################################################
x = list(range(742,788,2)) 

for i in range(len(x)):
	neg_dat = np.array(glob.glob('Twop_conf'+str(x[i])+'_+0_+0_-3.dat'))
	pos_dat = np.array(glob.glob('Twop_conf'+str(x[i])+'_+0_+0_+3.dat'))

	t_data = data_reader_2pt(pos_dat,0)
	p_data = data_reader_2pt(pos_dat,1)
	n_data = data_reader_2pt(neg_dat,1)

	f = open('test0'+str(x[i])+'_z_twop.txt','w')

	for j in range(len(t_data)):
		f.write(str(int(t_data[j]))+ " " + format(p_data[j], '.16e') + " "+ format(n_data[j], '.16e') + "\n")
	f.close()


